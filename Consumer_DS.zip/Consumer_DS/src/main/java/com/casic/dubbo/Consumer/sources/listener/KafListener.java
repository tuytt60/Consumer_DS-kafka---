package com.casic.dubbo.Consumer.sources.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;

import com.alibaba.fastjson.JSON;


public class KafListener {
	 protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	
		int i=0;
		 //监听多个主题
	    @KafkaListener(topics = {"shenjunbo"})
	    public void listen(List<ConsumerRecord> list) {
	    	//topic:value
	      if(list!=null&&!list.isEmpty()){
	    	  for (ConsumerRecord record : list) {
		    	  i++;
		    	  String value=String.valueOf(record.value());
		    		  System.out.println("----"+value);
		    	  if(i==10000){
		    		  new Runnable() {
		  				@Override
		  				public void run() {
		  					Map map = JSON.parseObject(value, Map.class);
		  					long createTime = Long.parseLong(String.valueOf(map.get("createTime")));
		  					System.out.println("10000次: "+(System.currentTimeMillis()-createTime));
		  					i=0;
		  				}
		  			}.run();
		    	  }
			}
	    	 
	    	 
	      }
	    	
	    
	    }
	    
}
