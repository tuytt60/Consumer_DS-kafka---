package com.casic.dubbo.Consumer.sources.model;

import java.util.Properties;


public class KafkaProducerSimple {
	
	private static String topic="test";


}
